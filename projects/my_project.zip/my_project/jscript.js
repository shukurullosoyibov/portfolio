"use strict";

const seriesDB = {
  count: 0,
  series: {},
  actors: {},
  genres: [],
  private: false,
  start: function () {
    seriesDB.count = +prompt("Nechta serial ko'rdingiz?", "");

    while (
      seriesDB.count == "" ||
      seriesDB.count == null ||
      isNaN(seriesDB.count)
    ) {
      seriesDB.count = +prompt("Nechta serial ko'rdingiz?", "");
    }
  },
  rememberMySeries: function () {
    for (let i = 0; i < 2; i++) {
      const a = prompt("Oxirgi ko'rgan serialingiz?"),
        b = prompt("Nechi baxo berasiz?");

      if (a != null && b != null && a != "" && b != "") {
        seriesDB.series[a] = b;
        console.log("done");
      } else {
        console.log("error");
        i--;
      }
    }
  },
  detectLevelSeries: function () {
    if (seriesDB.count < 5) {
      console.log("Kam serial ko’ripsiz");
    } else if (seriesDB.count >= 5 && seriesDB.count < 10) {
      console.log("Siz classik tamoshabin ekansiz");
    } else if (seriesDB.count >= 10) {
      console.log("Siz serialchi zvezda ekansiz");
    } else {
      console.log("Error");
    }
  },
  showDb: function () {
    if (!seriesDB.private) {
      console.log(seriesDB);
    }
  },
  visibleDB: function () {
    seriesDB.private ? (seriesDB.private = false) : (seriesDB.private = true);
  },
  writeGenres: function () {
    for (let i = 0; i < 3; i++) {
      const genre = prompt(`Yaxshi ko'rgan janringiz ${i + 1}`, "");
      if (genre === "" || genre === null) {
        console.log("siz notogri kiritingiz qayta kiriting");
        i--;
      } else {
        seriesDB.genres[i] = genre;
      }
    }
    seriesDB.genres.forEach((key, i) => {
      console.log(`yaxshi korgan janiringiz ${i + 1} - nomi ${key}`);
    });
  },
};
